import java.util.Random;

/**
 * @author Anuj Dutt, UB - 50292024
 *
 */
public class ParTreeInsert {

	public static void main(String[] args) {

		Tree tr = new Tree(5000);

		int N = 5;

		InsertNums[] threads = { new InsertNums(tr), new InsertNums(tr), new InsertNums(tr), new InsertNums(tr),
				new InsertNums(tr) };

		try {
			System.out.println("Start Parallel Insert ...");
			for (int i = 0; i < N; i++) {
				threads[i].start();
			}
			for (int i = 0; i < N; i++) {
				threads[i].join();
			}
			System.out.println("Done Parallel Insert ...\nResults:");

			tr.print();

		} catch (Exception e) {
		}
	}
}

class InsertNums extends Thread {

	Tree tr;

	public InsertNums(Tree tr) {
		this.tr = tr;
	}

	public void run() {
		Random r = new Random();
		for (int i = 0; i < 5; i++) {
			tr.lock();
			tr.insert_par(r.nextInt(10000));
			tr.unlock();
		}
		tr = null;
	}
}

class Tree {
	public Tree(int n) {
		value = n;
		// left == right == null, by default
	}

	protected void insert(int n) {
		if (value == n)
			return;
		if (value < n)
			if (right == null)
				right = new Tree(n);
			else
				right.insert(n);

		else if (left == null)
			left = new Tree(n);
		else
			left.insert(n);
	}

	void print() {
		if (left != null)
			left.print();
		System.out.print(value + " ");
		if (right != null)
			right.print();
	}

	void insert_par(int n) {
		System.out.println("Inserting elements.");
		// define this method
		if (value == n) {
			return;
		}

		if (value < n) {
			if (right == null) {
				right = new Tree(n);
			} else {
				unlock();
				right.lock();
				right.insert_par(n);
				right.unlock();
			}
		} else if (left == null) {
			left = new Tree(n);
		} else {
			unlock();
			left.lock();
			left.insert_par(n);
			left.unlock();
		}
		System.out.println("Completed inserting elements.");
	}

	synchronized void lock() {

		// define this method
		while (isLocked) {
			try {
				this.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		isLocked = true;
		System.out.println("Lock acquired.");
	}

	synchronized void unlock() {
		// define this method
		System.out.println("Insert complete. Releasing lock.");
		isLocked = false;
		System.out.println("Lock released. Notifying other threads.");
		this.notifyAll();
	}

	protected int value;
	protected Tree left, right;

	// okay to add extra fields
	boolean isLocked = false;

}
