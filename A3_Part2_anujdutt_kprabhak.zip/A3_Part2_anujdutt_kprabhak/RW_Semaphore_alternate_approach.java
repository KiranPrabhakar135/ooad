/**
 * 
 */

import java.util.concurrent.Semaphore;

/**
 * @author Anuj Dutt, UB - 50292024
 * @author Kiran Prabhakar, UB - 50287403
 *
 */



// Readers-Writers with Writer Priority

public class RW_Semaphore_alternate_approach {


    public static void main(String[] args) {

        Semaphore syncSemaphore = new Semaphore(1);
        Semaphore readerSemaphore = new Semaphore(5);
        Semaphore writerSemaphore = new Semaphore(1);
        Database d = new Database(syncSemaphore, readerSemaphore, writerSemaphore);
        Writer w1 = new Writer(d, 1);
        Writer w2 = new Writer(d, 10);
        Writer w3 = new Writer(d, 100);
        Writer w4 = new Writer(d, 1000);
        Writer w5 = new Writer(d, 10000);

        Reader r1 = new Reader(d);
        Reader r2 = new Reader(d);
        Reader r3 = new Reader(d);
        Reader r4 = new Reader(d);
        Reader r5 = new Reader(d);

        w1.start();
        r1.start();
        r2.start();
        r3.start();
        w2.start();
        w3.start();
        w4.start();
        w5.start();
        r4.start();
        r5.start();
    }
}

class Reader extends Thread {
    Database d;

    public Reader(Database d) {
        this.d = d;
    }

    public void run() {

        for (int i = 0; i < 5; i++) {


            d.request_read();
            System.out.println(d.read());
            d.done_read();

        }
    }
}

class Writer extends Thread {

    Database d;
    int x;


    public Writer(Database d, int x) {
        this.d = d;
        this.x = x;
    }

    public void run() {
        for (int i = 0; i < 5; i++) {
            d.request_write();
            d.write(x);
            try {
                Thread.sleep(50);
            } catch (Exception e) {
            }
            d.done_write();
        }
    }
}


class Database {
    int data = 0;
    int r = 0;   // # active readers
    int w = 0;   // # active writers (0 or 1)
    int ww = 0;  // # waiting writers
    int wr = 0;  // # waiting readers

    Semaphore mutex;
    Semaphore readerSemaphore;
    Semaphore writerSemaphore;

    public Database(Semaphore mutex, Semaphore readerSemaphore, Semaphore writerSemaphore) {
        this.mutex = mutex;
        this.readerSemaphore = readerSemaphore;
        this.writerSemaphore = writerSemaphore;
    }

    public void request_read() {
        try {
            mutex.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        while (w == 1 || ww > 0) {
            try {
                writerSemaphore.release();
                wr++;
                mutex.release();
                writerSemaphore.acquire();
                mutex.acquire();
                wr--;
            } catch (Exception e) {
            }
        }
        try {
            readerSemaphore.acquire();
        } catch (Exception e) {
        }
        r++;
        writerSemaphore.release();
        mutex.release(); 
    }

    public void done_read() {
    	try {
            mutex.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        r--;
        readerSemaphore.release();
        mutex.release(); 
    }

    public void request_write() {
        try {
            mutex.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        while (r > 0 || w == 1) {
            try {
                ww++;
                mutex.release();
                writerSemaphore.acquire();
                mutex.acquire();
                ww--;
            } catch (Exception e) {
            }
        }
        w = 1;
        mutex.release(); 
    }

    public void done_write() {
    	try {
            mutex.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        w = 0;
        writerSemaphore.release();
        mutex.release();
    }

    int read() {
        return data;
    }

    void write(int x) {
        data = data + x;
    }
}

