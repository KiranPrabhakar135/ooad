package main.java;

import com.google.java.contract.Requires;

public class home {

    public static void main(String[] args) {
        test(2);
    }

    @Requires("a > 3")
    public static void test(int a) {
        System.out.println("" + a);
    }
}